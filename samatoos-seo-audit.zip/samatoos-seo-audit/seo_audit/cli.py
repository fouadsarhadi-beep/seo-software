"""Command line. Run:  python -m seo_audit <command> --help
Commands: crawl, variants, analyze, review, calibrate, gsc-pull.
Where a decision belongs to you, the tool asks you instead of guessing."""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

from . import __version__, analyze, crawl, fa_text, gsc, review, similarity, variants as variants_mod

DEFAULT_SITEMAP = "https://samatoos.ir/sitemap_index.xml"


def ask(question, default="", input_fn=input):
    suffix = f" [{default}]" if default else ""
    ans = input_fn(f"{question}{suffix}: ").strip()
    return ans or default


def _interactive(args) -> bool:
    return sys.stdin.isatty() and not getattr(args, "yes", False)


def cmd_crawl(args, input_fn=input):
    inter = _interactive(args)
    sitemap_url = args.sitemap or (ask("Sitemap address", DEFAULT_SITEMAP, input_fn) if inter else DEFAULT_SITEMAP)
    robots = args.robots
    if robots is None:
        robots = "respect"
        if inter and ask("Respect robots.txt? (recommended)", "Y", input_fn).lower().startswith("n"):
            robots = "ignore"
    page_types = []
    if inter and not args.config:
        pat = ask("Optional: a URL pattern (regex) that marks blog posts, e.g. /blog/  (Enter to skip)", "", input_fn)
        if pat:
            page_types = [{"name": "blog", "url_regex": pat}]
    selector = args.content_selector
    if inter and not selector:
        selector = ask("Optional: CSS selector of the article text (Enter = automatic)", "", input_fn)
    cfg = crawl.CrawlConfig(sitemap=sitemap_url, out_dir=args.out_dir, delay=args.delay, retries=args.retries,
                            limit=args.limit, max_redirects=args.max_redirects, allowed_hosts=args.allowed_host or [],
                            robots=robots, content_selector=selector or "", exclude_selectors=args.exclude_selector or [],
                            skip_sitemap=args.skip_sitemap, config_file=args.config or "",
                            variants_file=args.variants or "", page_types=page_types,
                            user_agent=args.user_agent or crawl.CrawlConfig.__dataclass_fields__["user_agent"].default,
                            csv_guard=not args.no_csv_guard)
    if inter and ask(f"Crawl {sitemap_url} now (one request at a time, {cfg.delay}s apart)?", "Y", input_fn).lower().startswith("n"):
        print("Cancelled.")
        return 1
    crawl.run_crawl(cfg, input_fn=input_fn if inter else None)
    print(f"\nNext: python -m seo_audit variants --in-dir {cfg.out_dir}   (optional, Persian spelling variants)\n"
          f"      python -m seo_audit analyze --in-dir {cfg.out_dir}")
    return 0


def cmd_variants(args, input_fn=input):
    recs = analyze.load_snapshot(Path(args.in_dir) / "snapshot.jsonl")
    toks = [fa_text.tokenize(r["text"]) for r in recs if r["fetch_state"].startswith("ok")]
    cands = variants_mod.find_candidates(toks, min_split=args.min_count)
    if not cands:
        print("No spelling-variant candidates found.")
        return 0
    path = Path(args.variants or Path(args.in_dir) / "persian_variants.json")
    print(f"{len(cands)} candidate(s). You approve each one; nothing is applied without your answer.")
    ok = variants_mod.review(cands, path, input_fn)
    print(f"{len(ok)} variant(s) saved in {path}. 'analyze' will use them automatically.")
    return 0


def cmd_analyze(args, input_fn=input):
    inter = _interactive(args)
    pages, qp = args.gsc_pages, args.gsc_queries
    if inter and not pages:
        pages = ask("Optional: path to a Search Console 'Pages' export CSV (Enter to skip)", "", input_fn) or None
    if inter and not qp:
        qp = ask("Optional: path to a query-by-page CSV from 'gsc-pull' (Enter to skip)", "", input_fn) or None
    s = similarity.Settings(shingle=args.shingle, min_words=args.min_words, thr_dup=args.min_dup,
                            thr_contain=args.min_contain, thr_topic=args.min_topic, thr_title=args.min_title,
                            bigrams=not args.no_bigrams, brand_terms=tuple(args.brand or []))
    analyze.run_analyze(args.in_dir, args.out_dir, pages, qp, s, args.stopwords, args.variants, args.normalizer,
                        args.stem, args.include_noindex)
    out = args.out_dir or args.in_dir
    print(f"\nNext: python -m seo_audit review --in-dir {out}    (you decide, pair by pair)")
    return 0


def cmd_review(args, input_fn=input):
    d = Path(args.in_dir)
    pairs = json.loads((d / "pairs.json").read_text(encoding="utf-8"))
    dec_path = Path(args.decisions or d / "decisions.jsonl")
    review.review_loop(pairs, dec_path, args.min_evidence, args.limit, input_fn)
    decisions = review.load_decisions(dec_path)
    if decisions:
        with open(d / "decisions.csv", "w", newline="", encoding="utf-8-sig") as fh:
            w = csv.writer(fh)
            w.writerow(["URL A", "URL B", "Decision", "Note", "Decided at (UTC)"])
            for x in decisions.values():
                w.writerow([x["url_a"], x["url_b"], x["decision"], x["note"], x["ts"]])
        print(f"Your decisions are also in {d / 'decisions.csv'}.")
    return 0


def cmd_calibrate(args, input_fn=input):
    d = Path(args.in_dir)
    pairs = json.loads((d / "pairs.json").read_text(encoding="utf-8"))
    text = review.calibrate(pairs, Path(args.decisions or d / "decisions.jsonl"))
    (d / "calibration.txt").write_text(text, encoding="utf-8")
    return 0


def cmd_gsc_pull(args, input_fn=input):
    prop = args.property or ask("Search Console property (e.g. sc-domain:samatoos.ir or https://samatoos.ir/)", "", input_fn)
    start_d, end_d = gsc.default_dates(args.days)
    start, end = args.start or start_d, args.end or end_d
    print(f"Read-only access. Property: {prop}. Dates: {start} to {end} (Search Console uses Pacific Time).")
    try:
        service = gsc.build_service(args.credentials, args.token)
    except ImportError:
        print("Install the optional packages first:  pip install google-api-python-client google-auth-oauthlib")
        return 1
    meta = gsc.pull_api(service, prop, start, end, args.out, data_state=args.data_state)
    print(f"{meta['rows']} rows saved to {args.out}. Remember: the API returns top rows only; a missing row proves nothing.")
    return 0


def build_parser():
    p = argparse.ArgumentParser(prog="seo_audit", description="Analytics-only SEO audit tools. You make the decisions.")
    p.add_argument("--version", action="version", version=__version__)
    sub = p.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("crawl", help="read the sitemap and visit each page (read-only)")
    c.add_argument("--sitemap"); c.add_argument("--out-dir", default="audit_out")
    c.add_argument("--delay", type=float, default=0.5); c.add_argument("--retries", type=int, default=2)
    c.add_argument("--limit", type=int, default=0, help="crawl only the first N URLs (test run)")
    c.add_argument("--robots", choices=["respect", "ignore"], default=None)
    c.add_argument("--allowed-host", action="append"); c.add_argument("--max-redirects", type=int, default=5)
    c.add_argument("--content-selector", default=""); c.add_argument("--exclude-selector", action="append")
    c.add_argument("--skip-sitemap", default=crawl.CrawlConfig.skip_sitemap)
    c.add_argument("--config"); c.add_argument("--variants"); c.add_argument("--user-agent")
    c.add_argument("--no-csv-guard", action="store_true"); c.add_argument("--yes", action="store_true", help="no questions")
    c.set_defaults(func=cmd_crawl)

    v = sub.add_parser("variants", help="find Persian spelling variants and ask you to approve them")
    v.add_argument("--in-dir", default="audit_out"); v.add_argument("--variants")
    v.add_argument("--min-count", type=int, default=2)
    v.set_defaults(func=cmd_variants)

    a = sub.add_parser("analyze", help="compare pages and check canonicals (no website requests)")
    a.add_argument("--in-dir", default="audit_out"); a.add_argument("--out-dir")
    a.add_argument("--gsc-pages"); a.add_argument("--gsc-queries")
    a.add_argument("--shingle", type=int, default=5); a.add_argument("--min-words", type=int, default=80)
    a.add_argument("--min-dup", type=float, default=0.35); a.add_argument("--min-contain", type=float, default=0.80)
    a.add_argument("--min-topic", type=float, default=0.60); a.add_argument("--min-title", type=float, default=0.60)
    a.add_argument("--no-bigrams", action="store_true"); a.add_argument("--brand", action="append")
    a.add_argument("--stopwords"); a.add_argument("--variants")
    a.add_argument("--normalizer", choices=["basic", "hazm"], default="basic")
    a.add_argument("--stem", action="store_true", help="Hazm stemming for the topic signal only (needs hazm)")
    a.add_argument("--include-noindex", action="store_true"); a.add_argument("--yes", action="store_true")
    a.set_defaults(func=cmd_analyze)

    r = sub.add_parser("review", help="go through flagged pairs; YOU decide each one")
    r.add_argument("--in-dir", default="audit_out"); r.add_argument("--decisions")
    r.add_argument("--min-evidence", type=int, default=1); r.add_argument("--limit", type=int, default=0)
    r.set_defaults(func=cmd_review)

    k = sub.add_parser("calibrate", help="compare thresholds with your own decisions")
    k.add_argument("--in-dir", default="audit_out"); k.add_argument("--decisions")
    k.set_defaults(func=cmd_calibrate)

    g = sub.add_parser("gsc-pull", help="optional: read-only Search Console query x page data via the API")
    g.add_argument("--property"); g.add_argument("--credentials", default="client_secret.json")
    g.add_argument("--token", default=str(Path.home() / ".config" / "seo_audit" / "gsc_token.json"))
    g.add_argument("--start"); g.add_argument("--end"); g.add_argument("--days", type=int, default=90)
    g.add_argument("--data-state", choices=["final", "all"], default="final")
    g.add_argument("--out", default="gsc_query_page.csv")
    g.set_defaults(func=cmd_gsc_pull)
    return p


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except RuntimeError as exc:
        print(f"\n{exc}")
        return 2
    except KeyboardInterrupt:
        print("\nStopped.")
        return 130
