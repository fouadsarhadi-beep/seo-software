"""Samatoos SEO audit tools: analytics only. The tools gather evidence; you make the decisions."""
__version__ = "2.0.0"
SCHEMA_VERSION = "2"
