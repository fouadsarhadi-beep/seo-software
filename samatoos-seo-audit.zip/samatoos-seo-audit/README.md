# Samatoos SEO audit tools (V2)

Analytics only. The tools gather evidence about your site and ask you before anything that needs judgment.
They never change your website: they read public pages (and, optionally, Search Console data).
You are the final judge of every decision.

## Install

    pip install -r requirements.txt        # requests + beautifulsoup4 (Python 3.9+)
    # optional: pip install hazm           # Persian spacing fixes; needs Python 3.12 or 3.13
    # optional: pip install google-api-python-client google-auth-oauthlib   # only for gsc-pull

Run everything from this folder as `python -m seo_audit <command>`.

## The workflow (you decide at every step marked YOU)

1. **crawl**: `python -m seo_audit crawl`
   Asks for the sitemap address, whether to respect robots.txt, an optional blog URL pattern, and an optional
   CSS selector for the article text. One request at a time, 0.5 s apart.
   Writes `audit_out/inventory.csv` (paste columns A to I into the tracker workbook, as before) and `snapshot.jsonl`.
   Use `--limit 20` for a test run. If robots.txt cannot be read, it stops and asks YOU.
2. **variants** (optional, recommended once): `python -m seo_audit variants`
   Finds spelling variants in your own text, such as «نرمافزار» vs «نرم افزار», and asks YOU to approve each.
3. **analyze**: `python -m seo_audit analyze`
   No website requests. Compares pages, checks canonicals, writes `similar_pairs.csv`, `canonical_report.csv`,
   `issues.txt`, `pairs.json`. Optional inputs: a Search Console Pages export and a query-by-page CSV.
   Change thresholds and re-run as often as you like.
4. **review**: `python -m seo_audit review`
   Shows each flagged pair with its evidence (scores, shared terms and phrases, clicks, shared queries).
   YOU choose: merge, keep both with a canonical, differentiate, or ignore. Saved one by one, resumable.
5. **calibrate**: `python -m seo_audit calibrate`
   Compares the thresholds with YOUR decisions (precision and recall). Marked PROVISIONAL below 20 decisions.
6. **gsc-pull** (optional): `python -m seo_audit gsc-pull`
   Read-only Search Console query-by-page data. Needs a Google Cloud OAuth client (Desktop app) saved as
   `client_secret.json`; you sign in yourself in the browser. Not tested against the real API (tested with a fake).

## What the signals mean

| Signal | Meaning |
| --- | --- |
| Near-duplicate | share of identical 5-word phrases (same wording) |
| Containment | share of the SHORTER page's phrases found in the other page |
| Topic overlap | TF-IDF cosine of words and word pairs (same subject, different wording) |
| Title / Same H1 | title word overlap without brand words / identical H1 |
| Independent signal families | text overlap, topic, headings, shared GSC queries: how many of those fired |

None of these proves keyword cannibalization or that a canonical is needed. They are reasons to look.
The thresholds (35%, 80%, 60%, 60%) are starting values, not Google rules.

## Persian specifics handled

- Arabic vs Persian yeh and kaf, Arabic-Indic vs Persian digits, tatweel, diacritics, presentation forms.
- Half-space (ZWNJ) equals a space: «نرم‌افزار» = «نرم افزار». Clitics (ها، تان، شان) are stop words.
- Joined spellings («نرمافزار», «میشود») only merge after you approve them (`variants`) or via optional Hazm.
- URLs: Persian slugs are compared decoded, so `%d8%a7` (WordPress, lower-case hex) equals `%D8%A7` and `ا`;
  Unicode and punycode domains are equal; the "URL (decoded)" column helps you match Search Console rows.
- Pages in windows-1256 are decoded; Search Console exports with Persian headers, Persian digits, `٫` and `;` load.

## Output files

`inventory.csv` (first 9 columns unchanged, then V2 columns), `similar_pairs.csv` (first 6 unchanged),
`canonical_report.csv`, `issues.txt` (errors, warnings, review items), `pairs.json`, `decisions.jsonl` / `decisions.csv`,
`calibration.txt`, `crawl_manifest.json`, `analysis_manifest.json` (versions, settings, counts, limitations).
Spreadsheet formula protection: a title starting with `= + - @` gets a leading apostrophe.

## Tests

    pip install pytest && python -m pytest tests -q        # 75+ offline tests, no real website is contacted

## Known limits

HTML-source crawl (JavaScript-generated content is not seen); robots Crawl-delay is not applied (not in RFC 9309);
no internal-link graph; no URL Inspection API; Search Console data is partial by design (top rows only).
